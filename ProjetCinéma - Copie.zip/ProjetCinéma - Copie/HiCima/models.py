from unicodedata import name
from django.db import models



CATEGORY_CHOICES={
    ('A','ACTION'),
    ('D','DRAMA'),
    ('C','COMEDY'),
    ('R','ROMANCE'),
}
class Category(models.Model):
    name=models.CharField(max_length=120)
    def __str__(self):
        return self.name
    
    
    

class Film(models.Model):
    title=models.CharField(max_length=100)
    description=models.TextField(max_length=1000)
    image=models.ImageField(upload_to='films')
    category=models.CharField(choices=CATEGORY_CHOICES,max_length=1)
    
    created_at=models.DateTimeField(auto_now_add=True)
    updated_at=models.DateTimeField(auto_now=True)
    

    def __str__(self):
        return self.title
    
    
