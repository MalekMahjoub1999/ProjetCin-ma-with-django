from unicodedata import category
from django.http import QueryDict
from django.shortcuts import render
from .models import Film


#on ecrit la logique pour envpoyer les données vers l interface

def home(request):
    list_films=Film.objects.all()
    context={"liste_films":list_films}
    return render(request,"index.html",context)
#importation du données de l'article
def detail(request,id_film):
    film=Film.objects.get(id=id_film)
    category=film.category
    films_en_relation=Film.objects.filter(category=category)
    return render(request,"detail.html",{"film":film,"FER":films_en_relation})


def search(request):
    #Get={"film":"café"}
    #envoie et ffichage du requete café
  query=request.GET['film']
  return render(request,"search.html",{"query":query})