
from django.urls import path
from .views import  login_cima
urlpatterns=[
path('login',login_cima ,name='login_cima')
]