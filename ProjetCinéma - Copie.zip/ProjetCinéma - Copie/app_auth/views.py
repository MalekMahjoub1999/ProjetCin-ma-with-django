import imp
from django.shortcuts import redirect, render
from django.contrib.auth import authenticate#methode d authentification de django
from django.contrib import messages

# Create your views here.
def login_cima(request):
    if request.method=="POST":#envoie du formulaire a laide du valeur post
        username=request.POST['username']
        pwd=request.POST["pwd"]
        user=authenticate(username=username,password=pwd)
        #je vais retourner la paersonne sur une page d 'acceueil
        if user is not None:
            return redirect("HiCima")#hicima.urls
        else:
            messages.error(request="erreur de connexion")
            return render(request,"login.html")
    return render(request,"login.html",)